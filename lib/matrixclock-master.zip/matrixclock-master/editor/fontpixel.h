#ifndef FONTPIXEL_H
#define FONTPIXEL_H

#include <QPushButton>

class FontPixel : public QPushButton
{
    Q_OBJECT

  public:
    explicit FontPixel();
};

#endif // FONTPIXEL_H

#ifndef FONTS_H
#define FONTS_H

#include <inttypes.h>

// This font data printed
#define VOID		0xA5

extern const uint8_t font_cp1251_08[];
extern const uint8_t font_smallnum[];

#endif // FONTS_H

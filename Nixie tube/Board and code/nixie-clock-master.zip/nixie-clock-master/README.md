# Nixie Clock
This repository contains the KiCAD files for the PCB and the Atmel Studio files for the code.

Uses the following libraries:
- Zak Kemble's [millis](https://github.com/zkemble/millis) library
- akafugu's [DS3231](https://github.com/akafugu/ds_rtc_lib) RTC library